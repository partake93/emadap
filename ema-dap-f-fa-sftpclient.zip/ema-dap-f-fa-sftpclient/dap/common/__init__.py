"""
Common utilities package.
"""
